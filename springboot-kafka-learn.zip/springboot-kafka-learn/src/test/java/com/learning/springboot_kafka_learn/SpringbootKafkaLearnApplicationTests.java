package com.learning.springboot_kafka_learn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKafkaLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
