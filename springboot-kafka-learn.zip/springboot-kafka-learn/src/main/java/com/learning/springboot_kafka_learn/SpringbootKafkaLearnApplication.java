package com.learning.springboot_kafka_learn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootKafkaLearnApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootKafkaLearnApplication.class, args);
	}

}
